from .consumer import AIOKafkaConsumer

__all__ = ["AIOKafkaConsumer"]
